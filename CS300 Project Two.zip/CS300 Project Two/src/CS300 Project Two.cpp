#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
#include <sstream>
#include <cctype>

// Course structure
struct Course {
    std::string courseNumber;
    std::string courseTitle;
    std::vector<std::string> prerequisites;
};

// Function to convert a string to uppercase
std::string toUpper(const std::string& str) {
    std::string result = str;
    std::transform(result.begin(), result.end(), result.begin(), ::toupper);
    return result;
}

// Function to load data from the file into the data structure
void loadDataStructure(std::vector<Course>& courses, const std::string& fileName, bool& dataAlreadyLoaded) {
    if (dataAlreadyLoaded) {
        std::cout << "Data structure is already loaded.\n";
        return;
    }

    std::ifstream inputFile(fileName);
    if (!inputFile.is_open()) {
        std::cerr << "Error: Unable to open file " << fileName << std::endl;
        return;
    }

    std::string line;
    while (std::getline(inputFile, line)) {
        std::istringstream iss(line);
        Course newCourse;

        // Read courseNumber and courseTitle
        if (std::getline(iss, newCourse.courseNumber, ',') &&
            std::getline(iss, newCourse.courseTitle, ',')) {

            // Read prerequisites
            while (std::getline(iss, line, ',')) {
                if (!line.empty()) {
                    newCourse.prerequisites.push_back(line);
                }
            }

            courses.push_back(newCourse);
        } else {
            std::cerr << "Error: Unable to parse line: " << line << std::endl;
        }
    }

    inputFile.close();
    dataAlreadyLoaded = true;
    std::cout << "Data loaded successfully.\n";
}

// Function to print an alphanumeric list of Computer Science and Math courses
void printCourseList(const std::vector<Course>& courses) {
    // Sort all courses by courseNumber
    std::vector<Course> sortedCourses = courses;
    std::sort(sortedCourses.begin(), sortedCourses.end(),
              [](const Course& a, const Course& b) { return a.courseNumber < b.courseNumber; });

    // Print the sorted list
    for (const auto& course : sortedCourses) {
        std::cout << course.courseNumber << ", " << course.courseTitle << std::endl;
    }
}

// Function to print course information based on courseNumber
void printCourseInformation(const std::vector<Course>& courses, const std::string& courseNumber) {
    auto it = std::find_if(courses.begin(), courses.end(),
                           [&courseNumber](const Course& c) { return toUpper(c.courseNumber) == toUpper(courseNumber); });

    if (it != courses.end()) {
        // Print course information
        std::cout << it->courseNumber << ", " << it->courseTitle << std::endl;

        // Print prerequisites
        if (!it->prerequisites.empty()) {
            std::cout << "Prerequisites: ";
            for (const auto& prereq : it->prerequisites) {
                std::cout << prereq << " ";
            }
            std::cout << std::endl;
        } else {
            std::cout << "No prerequisites for this course." << std::endl;
        }
    } else {
        std::cout << "Course not found." << std::endl;
    }
}

int main() {
    std::vector<Course> courses;
    bool dataLoaded = false;

    std::cout << "Welcome to the course planner.\n";

    while (true) {
        // Display menu options
        std::cout << "1. Load Data Structure.\n"
                     "2. Print Course List.\n"
                     "3. Print Course.\n"
                     "9. Exit\n"
                     "What would you like to do? ";

        int choice;
        std::cin >> choice;

        if (std::cin.fail()) {
            // Clear the input stream and ignore invalid input
            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            std::cout << "Invalid input. Please enter a number.\n";
            continue;
        }

        switch (choice) {
            case 1:
                loadDataStructure(courses, "courses.txt", dataLoaded);
                break;
            case 2:
                if (dataLoaded) {
                    std::cout << "Here is a sample schedule:\n";
                    printCourseList(courses);
                } else {
                    std::cout << "Please load data first (Option 1).\n";
                }
                break;
            case 3:
                if (dataLoaded) {
                    std::string courseNumber;
                    std::cout << "What course do you want to know about? ";
                    std::cin >> courseNumber;
                    printCourseInformation(courses, courseNumber);
                } else {
                    std::cout << "Please load data first (Option 1).\n";
                }
                break;
            case 9:
                std::cout << "Thank you for using the course planner!\n";
                return 0;
            default:
                std::cout << choice << " is not a valid option.\n";
        }
    }

    return 0;
}
